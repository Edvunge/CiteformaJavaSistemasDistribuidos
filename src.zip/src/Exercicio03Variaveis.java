public class Exercicio03Variaveis {
    public static void main(String[] args){

        float f;
        int i;
        f=2.14f;
        i= (int) f;
        System.out.println("f="+f);
        System.out.println("i="+i);


    }
}
