package empregado;

public class EmpregadoAssalariado {
    String nome = "António";
    float num1float = 176.5f;
    float num2float =  3.5f;

}
