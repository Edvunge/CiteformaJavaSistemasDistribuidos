public class Exercicio01Operadores {
    public static void main(String[] args){

        int i=3, j=4;
        float a=2.14f, b=3.52f;
        System.out.println("i="+i+",j="+j);
        System.out.println("i+j<>"+i+j);
        System.out.println("i+j="+(i+j));
        System.out.println("i-j="+(i-j));
        System.out.println("i*j="+(i*j));
        System.out.println("j/i="+(j/i));
        System.out.println("j%i="+(j%i));
        System.out.println("a="+a+",b="+b);
        System.out.println("a+b="+(a+b));
        System.out.println("a-b="+(a-b));
        System.out.println("a*b="+(a*b));
        System.out.println("b/a="+(b/a));
        System.out.println("b%a="+(b%a));

    }
}
