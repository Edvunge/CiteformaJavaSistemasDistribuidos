public class Exercicio03Operadores {
    public static void main(String[] args){

        int b=0;
        System.out.println("Resultado="+(2>3 && 4/b>0));
        System.out.println("Se chegar aqui, e' porque nao fiz");
        System.out.println("a divisao por zero");

    }

}
