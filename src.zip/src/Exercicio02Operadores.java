public class Exercicio02Operadores {
    public static void main(String[] args){

        int i=3,j=3,k=3,m=3;

        System.out.println("i="+i+" j="+j+" k="+k+" m="+m);
        System.out.println("i++="+(i++)+" i="+i);
        System.out.println("++j="+(++j)+" j="+j);
        System.out.println("k--="+(k--)+" k="+k);
        System.out.println("--m="+(--m)+" m="+m);

    }
}
